<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @author inspired from sales_report_graphs.php,v 0.01 2002/11/27 19:02:22 cwi Exp  Released under the GNU General Public License $
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: torvista 2019 Jun 16 Modified in v1.5.7 $
 */
// Finnish translation v1.5.7 by Nida Verkkopalvelu Oy (Ihsan Yuz) <ihsan@nida.fi>
define('BOX_REPORTS_SALES_REPORT_GRAPHS', 'Graafinen myyntiraportti');

