<?php
/**
 * @package admin
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: onlyFor139.php 18698 2011-05-04 14:50:06Z wilt $
 *
 *
 * NOTE: This file was only for v1.3.9, and should be deleted when upgrading.
 *
 *
 */
