<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: mc12345678 2019 Jun 29 New in v1.5.7 $
 **/
 // Finnish translation Ver. 1.5.7 by Nida Verkkopalvelu Oy (Ihsan Yuz) <ihsan@nida.fi>
 define('TEXT_EMAIL_ADDRESS_VALIDATE', 'Syötetty teksti ei ratkaise hyväksyttävää sähköpostiosoitetta. (Esim: Nimi &lt;email@domain&gt; tai &lt;email@domain&gt; tai email@domain tai mikä tahansa näiden yhdistelmä pilkuilla erotettuna.)');
 define('TEXT_BOOLEAN_VALIDATE', 'Arvon on oltava looginen arvo tai vastaava.');