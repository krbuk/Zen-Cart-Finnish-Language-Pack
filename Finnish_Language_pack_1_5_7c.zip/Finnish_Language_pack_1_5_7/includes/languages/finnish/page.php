<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2013 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Tue Jan 15 15:50:09 2013 -0500 New in v1.5.2 $
 */
// Finnish translation v1.5.5 by Nida Verkkopalvelu Oy (Ihsan Yuz) <ihsan@nida.fi>
define('ERROR_PAGE_NOT_FOUND', 'Valitettavasti sivua jota yritit käyttää ei löydy.');
